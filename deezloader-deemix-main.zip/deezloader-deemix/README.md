# deezlodaer-deemix

This is an alternative WebUI for deemix based on Deezloader Remix, it should be used with deemix-pyweb or something like that.<br>
It's still in development, so it might have bugs

# How to use this
Replace the content of the webui folder with this repo

# Known issues
- Some toast messages don't appear

# License

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
